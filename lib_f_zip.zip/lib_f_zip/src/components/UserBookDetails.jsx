import React from 'react'

const UserBookDetails = () => {
  return (
    <div>UserBookDetails</div>
  )
}

export default UserBookDetails
import React from 'react'
import { Link, useLocation } from 'react-router-dom'

const NavBar = () => {
  const location = useLocation();
  console.log("page location is:-", location.pathname);
  return (
    <div className='flex w-full h-[60px] bg-[rgba(10,10,10,0.6)] justify-around items-center'>

  


      <div className='w-full h-full flex justify-center items-center'>
        <input type="text" placeholder='Please Enter User Name' className='h-[60%] w-[50%] rounded-md indent-3 outline-none' />
        <button className='text-white bg-blue-500 h-[60%] rounded-md mx-1 px-3 hover:bg-blue-600'>Search</button>
      </div>

        <div className=' w-40 h-[60px] flex justify-center items-center'>
        {location.pathname === "/" ? <Link to="/issue-book"> <button className='p-2 bg-green-700 rounded-md text-white'>Issue Book</button></Link> : <Link to="/">
          <button className='p-2 bg-yellow-700 rounded-md text-white'>Return Book</button></Link>}
      </div>

    </div>
  )
}

export default NavBar
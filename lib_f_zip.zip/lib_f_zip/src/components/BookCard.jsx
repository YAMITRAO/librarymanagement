import axios from 'axios';
import moment from 'moment'

const BookCard = ({bookData, updateDataFun}) => {
  
     
    const handleUpdateReturn = async(e) => {

        try{
            // console.log("update clicked and the id is :-", e.target.value);
        let respdata = await axios.put('http://localhost:3010/update-user', {
            id: e.target.value,
        })
          updateDataFun()
        }
        catch(err){
            console.log(err?.message)
        }
        
    }
    return (
        <div className='bg-[rgba(25,25,25)] w-64 p-2 flex justify-center items-center rounded-lg'>
            <div className=' text-white whitespace-wrap px-4 py-4  w-56 overflow-auto flex flex-col gap-6'>

                <div>Book Title: <span className='font-semibold  text-yellow-200'>{bookData.book_title}</span> </div>

                <div>
                    Issued Date: <span className='font-semibold text-yellow-200'>{moment(bookData.issued_date).format("ll")}</span>
                </div>

                <div>
                    Return Date: <span className='font-semibold text-yellow-200'>{moment(bookData.return_date).format("ll")}</span>
                </div>

                <div>
                     Fine Amount: <span className='font-bold text-red-500'>{bookData.fine_amount}</span>
                </div>

                <button className='bg-green-500 w-fit px-2 py-1 rounded-md  hover:bg-green-600' value={bookData.id} onClick={handleUpdateReturn}>Return Book</button>
            </div>

        </div>
    )
}

export default BookCard
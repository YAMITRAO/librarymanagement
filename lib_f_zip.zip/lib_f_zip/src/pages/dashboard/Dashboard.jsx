import React, { useEffect, useState } from 'react'
import BookCard from '../../components/BookCard'
import moment from 'moment';
import NavBar from "../../components/NavBar"

const Dashboard = ({data, updateDataFun,}) => {


    const [issedBookData, setIssuedBookData] = useState([]);
    const [returnedBookData, setReturnedBookData] = useState([]);
    
    const filteredData = (data) => {
        setIssuedBookData([]);
        setReturnedBookData([])
        data.map( val => {
            if(val.isReturn){
                setReturnedBookData((prev) => [...prev, val])
            }
            else{
                setIssuedBookData((prev)=> [...prev, val])
            }
        })
    }

    // console.log("Issued books", issedBookData);
    // console.log("Returned book data", returnedBookData)

    useEffect(()=> {
        filteredData(data)
    }, [data])
   
    return (
        <>
         <NavBar />
            {issedBookData && <div className='bg-slate-100  h-fit p-4 mt-4 '>
                <div>
                    <h2 className='text-black text-2xl font-semibold w-full text-center mb-2'>Assigned Books to {"User1"} </h2>
                </div>
                <div className=' flex gap-4 overflow-auto p-8'>
                    {
                        issedBookData?.map((val) => <BookCard key={val.id} bookData ={val} updateDataFun ={updateDataFun} />)
                    }
                     {!issedBookData.length && <div className='w-full text-center font-bold text-yellow-600'>No Data Avilable</div>}
                </div>
               
            </div>}

           { returnedBookData && <div className='bg-slate-100  h-fit p-4 mt-4'>
                <div>
                    <h2 className='text-black text-2xl font-semibold w-full text-center mb-2'>User History  </h2>
                </div>

                <div>
                    <table className=' w-full tableCustomDesign'>
                        <thead className='bg-slate-600 text-white '>
                            <tr className='font-thin '>
                                <th className='font-semibold border p-[2px]'>Sr</th>
                                <th className='font-semibold border'>Book Title</th>
                                <th className='font-semibold border'>Issued Date</th>
                                <th className='font-semibold border'>Return Date</th>
                                <th className='font-semibold border'>Fine Amount</th>
                                <th className='font-semibold border'>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                returnedBookData?.map((val, index) => <tr key={val.id} className='text-center'>
                                    <td className='p-2'>{index+1}</td>
                                    <td>{val.book_title}</td>
                                    <td>{moment(val.issued_date).format("ll")}</td>
                                    <td>{moment(val.return_date).format("ll")}</td>
                                    <td>{val.fine_amount}</td>
                                    <td>
                                        <button className='bg-yellow-700 text-white px-2 rounded hover:bg-yellow-800' value={val.id}> View </button>
                                    </td>
                                </tr> )
                            }
                           
                        </tbody>
                    </table>
                </div>
            </div>
            }
        </>

    )
}

export default Dashboard
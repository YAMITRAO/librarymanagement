import React, { useState } from 'react'
import NavBar from '../../components/NavBar'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const IssueBook = ({updateDataFun}) => {
    const [issueBook, setIssueBook] = useState("");
     const navigate = useNavigate();

    const handleIssueBook = async(e)=> {
        e.preventDefault();
       
        try{
            let response = axios.post("http://localhost:3010/issue-book", {
                book_title: issueBook
            });
            console.log("Response is:-", response);
             setIssueBook("");
             updateDataFun();
             navigate("/")
        }
        catch(err){
            console.log("err", err)
        }

      
        
    }
  return (
    <>
    <NavBar/>
    <div className='  p-4  flex justify-center  '>
        <form onSubmit={handleIssueBook} className='mt-10 mb-10 bg-slate-500 rounded-md py-10 px-6 text-white flex flex-col w-full max-w-[600px]'>

        <div className='flex flex-col items-center mb-4'>
            <label className='text-xl pb-2 font-mono font-semibold '>Book Title</label>
            <input type="text" placeholder='Enter Book Title' name="book_title" className='w-full h-10 indent-3 rounded-lg outline-none text-black' value={issueBook} onChange={(e)=> setIssueBook(e.target.value)} required/>
        </div>

        <div className='flex flex-col items-center'>
        <input type="submit"  className='w-full h-10  rounded-lg bg-yellow-600 cursor-pointer hover:bg-yellow-700' value="Submit" />
        </div>
        </form>
    </div>
    </>
  )
}

export default IssueBook
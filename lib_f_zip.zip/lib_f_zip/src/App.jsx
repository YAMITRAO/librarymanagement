
import { useEffect, useState } from 'react'
import './App.css'
// import NavBar from './components/NavBar'
import Dashboard from './pages/dashboard/Dashboard'
import axios from 'axios'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import IssueBook from './pages/bookIssue/IssueBook'

function App() {

  const [userData, setUserData] = useState([])

  const getUserData = async() => {

    try{
      let data = await axios("http://localhost:3010/get-user");
      // console.log("Data is ", data.data.data);
      setUserData(data.data.data);

    }
    catch(err){
      console.log("error is", err)
    }
  }

  const router = createBrowserRouter([
    {
      path :"/",
      element: <Dashboard data= {userData} updateDataFun = {getUserData()}/>
    }, {
      path :"/issue-book",
      element: <IssueBook updateDataFun = {getUserData}/>
    }
  ])

  
  useEffect(()=> {
    getUserData();
  },[] )
  

  return (
    <>
   
    <RouterProvider router={router}>
    
    </RouterProvider>
      
    </>
  )
}

export default App

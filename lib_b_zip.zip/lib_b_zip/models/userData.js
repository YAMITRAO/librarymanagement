const Sequelize = require("sequelize");

const sequelizedb = require("../util/database");


const User = sequelizedb.define("user", {

    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
      },
      book_title :Sequelize.STRING,
      issued_date: Sequelize.DATE,
      return_date : Sequelize.DATE,
      fine_amount: Sequelize.STRING,
      isReturn: Sequelize.BOOLEAN
})

module.exports = User;


const express = require("express");
const bodyParesre = require("body-parser");
const cors = require("cors");
const app = express();
const PORT = 3010;

const sequelizedb = require("./util/database");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}))
app.use(bodyParesre.json());

app.use("/", require("./routes/index"))


sequelizedb.sync().then((result)=> {
    // console.log("Synceeedddd", result);
    app.listen(PORT, ()=> {
        console.log("Server is running on:-", PORT)
    });
    console.log("Connected to mysql data base");
}).catch((err)=> console.log("errrororo", err))


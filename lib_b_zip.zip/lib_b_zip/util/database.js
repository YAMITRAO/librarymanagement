// const mysql = require("mysql2");

// const pool = mysql.createPool({
//     host: 'localhost',
//     database:'lib_app',
//     user: 'root',
//     password: "yADAV@12236",
// })

// module.exports = pool.promise();

const sequelize = require("sequelize");

const sequelizedb = new sequelize('lib_app', 'root', 'yADAV@12236', {
    dialect: 'mysql',
    host: 'localhost'
  });


  module.exports = sequelizedb;
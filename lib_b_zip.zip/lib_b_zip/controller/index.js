const { response } = require("express");
const sequelizedb = require("../util/database");
const userData = require("../models/userData");


const userGetDataController = async (req, res) => {
    try {
         let userDataResponse = await userData.findAll();

         userDataResponse.map(async (val,index)=> 
            {
                if(val.dataValues.isReturn){
                    return
                }
                let findUser = await userData.findByPk(val.dataValues.id);
               
                const returnDate = new Date(val.dataValues.return_date);
                const currentDate = new Date();

        //         const futureDate = new Date();
        // await futureDate.setDate(futureDate.getDate() -2 );

                if(returnDate > currentDate){
                    await findUser.update({fine_amount: "0"});
                }
                else{
                    console.log("over due");
                    const differenceInTime = currentDate - returnDate;
                    const differenceInDays = parseInt(differenceInTime / (1000 * 3600 * 24));
                    console.log("overdue time is :-", differenceInDays, "......................");
                    let total_fine = differenceInDays*10;
                    await findUser.update({fine_amount: total_fine });
                }
            }
        )

        res.status(200).json({
            message:"User data fetch successfully",
            error: false,
            success: true,
            data: userDataResponse
        })

    }
    catch (err) {
        res.status(400).json({
            message: "Error in getting data",
            error: true,
            success: false,
            data: []
        })
    }
}

const userUpdateController = async(req, res) => {
    try{
        console.log("Update data is here", req.body);
        let findUser = await userData.findByPk(req.body.id)
        console.log("fineded value is", findUser);

        if (!findUser) {
            console.log('User not found');
            res.status(400).json({
                message:"Data not foun",
                error:true,
                success:false,
                data:[]
            });
        }


           await findUser.update({isReturn : true})

          res.status(201).json({
            message: "User Updated Successfully",
            error: false,
            success: true,
            data: findUser
        })

    }
    catch(err){
        res.status(400).json({
            message: "Error in getting data",
            error: true,
            success: false,
            data: []
        })
    }
}


const userPostController = async(req, res) => {
    try{
         let currentDate = new Date();
        const futureDate = new Date();
        await futureDate.setDate(futureDate.getDate() + 15 );
       
        let creationResponse = await userData.create({
            book_title: req.body.book_title,
            issued_date: currentDate,
            return_date: futureDate,
            isReturn: false,
            fine_amount: "0"
        })

        console.log("post update :--", req.body);
        res.status(201).json({
            message: "Issed Book Successfully",
            error: false,
            success: true,
            data: creationResponse
        })


    }
    catch(err){
        res.status(400).json({
            message: "Error in getting data",
            error: true,
            success: false,
            data: []
        })
    }
}



module.exports = {
    userGetDataController,
    userUpdateController,
    userPostController
}
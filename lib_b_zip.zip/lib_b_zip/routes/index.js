

const express = require("express");
const { userGetDataController, userUpdateController, userPostController } = require("../controller");

const router = express.Router();

router.get("/get-user", userGetDataController);
router.put("/update-user", userUpdateController );
router.post("/issue-book", userPostController)



module.exports = router;